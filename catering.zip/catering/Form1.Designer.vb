﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        PictureBox1 = New PictureBox()
        lblTitle = New Label()
        GroupBox1 = New GroupBox()
        radFruits = New RadioButton()
        radSausage = New RadioButton()
        radVeggie = New RadioButton()
        radWraps = New RadioButton()
        radCheese = New RadioButton()
        GroupBox2 = New GroupBox()
        radPickup = New RadioButton()
        radPre = New RadioButton()
        lblPay = New Label()
        lblLoyalty = New Label()
        lblResults = New Label()
        txtPoints = New TextBox()
        btnCalculate = New Button()
        btnClear = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(413, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(375, 220)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(134, 21)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(133, 60)
        lblTitle.TabIndex = 1
        lblTitle.Text = "Catering " & vbCrLf & "Star Market " & vbCrLf
        lblTitle.TextAlign = ContentAlignment.TopCenter
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackColor = Color.AntiqueWhite
        GroupBox1.Controls.Add(radFruits)
        GroupBox1.Controls.Add(radSausage)
        GroupBox1.Controls.Add(radVeggie)
        GroupBox1.Controls.Add(radWraps)
        GroupBox1.Controls.Add(radCheese)
        GroupBox1.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GroupBox1.ForeColor = Color.AntiqueWhite
        GroupBox1.Location = New Point(32, 111)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(351, 213)
        GroupBox1.TabIndex = 2
        GroupBox1.TabStop = False
        GroupBox1.Text = "GroupBox1"
        ' 
        ' radFruits
        ' 
        radFruits.AutoSize = True
        radFruits.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radFruits.ForeColor = SystemColors.ControlText
        radFruits.Location = New Point(46, 177)
        radFruits.Name = "radFruits"
        radFruits.Size = New Size(93, 21)
        radFruits.TabIndex = 4
        radFruits.TabStop = True
        radFruits.Text = "Fruit $29.99"
        radFruits.UseVisualStyleBackColor = True
        ' 
        ' radSausage
        ' 
        radSausage.AutoSize = True
        radSausage.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radSausage.ForeColor = SystemColors.ControlText
        radSausage.Location = New Point(46, 137)
        radSausage.Name = "radSausage"
        radSausage.Size = New Size(189, 21)
        radSausage.TabIndex = 3
        radSausage.TabStop = True
        radSausage.Text = "Sausage and Cheese $49.99"
        radSausage.UseVisualStyleBackColor = True
        ' 
        ' radVeggie
        ' 
        radVeggie.AutoSize = True
        radVeggie.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radVeggie.ForeColor = SystemColors.ControlText
        radVeggie.Location = New Point(46, 100)
        radVeggie.Name = "radVeggie"
        radVeggie.Size = New Size(108, 21)
        radVeggie.TabIndex = 2
        radVeggie.TabStop = True
        radVeggie.Text = "Veggie $29.99"
        radVeggie.UseVisualStyleBackColor = True
        ' 
        ' radWraps
        ' 
        radWraps.AutoSize = True
        radWraps.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radWraps.ForeColor = SystemColors.ControlText
        radWraps.Location = New Point(46, 63)
        radWraps.Name = "radWraps"
        radWraps.Size = New Size(160, 21)
        radWraps.TabIndex = 1
        radWraps.TabStop = True
        radWraps.Text = "Pinwheel Wraps $59.99"
        radWraps.UseVisualStyleBackColor = True
        ' 
        ' radCheese
        ' 
        radCheese.AutoSize = True
        radCheese.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radCheese.ForeColor = SystemColors.ControlText
        radCheese.Location = New Point(46, 25)
        radCheese.Name = "radCheese"
        radCheese.Size = New Size(165, 21)
        radCheese.TabIndex = 0
        radCheese.TabStop = True
        radCheese.Text = "Gourmet Cheese $49.99"
        radCheese.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.BackColor = Color.AntiqueWhite
        GroupBox2.Controls.Add(radPickup)
        GroupBox2.Controls.Add(radPre)
        GroupBox2.ForeColor = Color.AntiqueWhite
        GroupBox2.Location = New Point(78, 364)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(248, 123)
        GroupBox2.TabIndex = 3
        GroupBox2.TabStop = False
        GroupBox2.Text = "GroupBox2"
        ' 
        ' radPickup
        ' 
        radPickup.AutoSize = True
        radPickup.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radPickup.ForeColor = SystemColors.ActiveCaptionText
        radPickup.Location = New Point(23, 74)
        radPickup.Name = "radPickup"
        radPickup.Size = New Size(138, 24)
        radPickup.TabIndex = 1
        radPickup.TabStop = True
        radPickup.Text = "Pay upon Pickup "
        radPickup.UseVisualStyleBackColor = True
        ' 
        ' radPre
        ' 
        radPre.AutoSize = True
        radPre.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radPre.ForeColor = SystemColors.ControlText
        radPre.Location = New Point(23, 30)
        radPre.Name = "radPre"
        radPre.Size = New Size(76, 24)
        radPre.TabIndex = 0
        radPre.TabStop = True
        radPre.Text = "Pre-Pay"
        radPre.UseVisualStyleBackColor = True
        ' 
        ' lblPay
        ' 
        lblPay.AutoSize = True
        lblPay.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPay.Location = New Point(78, 531)
        lblPay.Name = "lblPay"
        lblPay.Size = New Size(109, 25)
        lblPay.TabIndex = 4
        lblPay.Text = "Please Pay:"
        ' 
        ' lblLoyalty
        ' 
        lblLoyalty.AutoSize = True
        lblLoyalty.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblLoyalty.Location = New Point(478, 299)
        lblLoyalty.Name = "lblLoyalty"
        lblLoyalty.Size = New Size(146, 25)
        lblLoyalty.TabIndex = 5
        lblLoyalty.Text = "Loyalty Points: "
        ' 
        ' lblResults
        ' 
        lblResults.AutoSize = True
        lblResults.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblResults.Location = New Point(221, 531)
        lblResults.Name = "lblResults"
        lblResults.Size = New Size(45, 20)
        lblResults.TabIndex = 6
        lblResults.Text = "$000"
        ' 
        ' txtPoints
        ' 
        txtPoints.Location = New Point(647, 301)
        txtPoints.Name = "txtPoints"
        txtPoints.Size = New Size(71, 23)
        txtPoints.TabIndex = 7
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(452, 419)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(113, 38)
        btnCalculate.TabIndex = 8
        btnCalculate.Text = "Calculate "
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(647, 419)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(113, 38)
        btnClear.TabIndex = 9
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.PeachPuff
        ClientSize = New Size(800, 585)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(txtPoints)
        Controls.Add(lblResults)
        Controls.Add(lblLoyalty)
        Controls.Add(lblPay)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Controls.Add(lblTitle)
        Controls.Add(PictureBox1)
        Name = "Form1"
        Text = "Catering "
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radFruits As RadioButton
    Friend WithEvents radSausage As RadioButton
    Friend WithEvents radVeggie As RadioButton
    Friend WithEvents radWraps As RadioButton
    Friend WithEvents radCheese As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents radPickup As RadioButton
    Friend WithEvents radPre As RadioButton
    Friend WithEvents lblPay As Label
    Friend WithEvents lblLoyalty As Label
    Friend WithEvents lblResults As Label
    Friend WithEvents txtPoints As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button

End Class
