﻿Public Class Form1
    Const loyalty As Integer = 10
    Const discount As Decimal = 0.05
    Const cheese As Decimal = 49.99
    Const wraps As Decimal = 59.99
    Const veggie As Decimal = 29.99
    Const sausage As Decimal = 49.99
    Const fruits As Decimal = 29.99
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        radCheese.Checked = True
        radPre.Checked = True
        txtPoints.Focus()
        lblResults.Text = ""

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtPoints.Text = ""
        lblResults.Text = ""
        radCheese.Checked = True
        radPre.Checked = True
        txtPoints.Focus()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim conversion As Decimal
        Dim calculate As Decimal
        Dim percentage As Decimal
        Dim results As Decimal
        Dim resultstext As String
        Dim conversiontext As String

        If IsNumeric(txtPoints.Text) Then
            conversion = Convert.ToDecimal(txtPoints.Text)
            If conversion >= 0 Then
                If radCheese.Checked = True Then
                    If radPre.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = cheese - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Gourmet Cheese Plater costs " + resultstext + " using Pre-Pay after discount of " + conversiontext + " loyalty points."
                    ElseIf radPickup.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = cheese - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Gourmet Cheese Plater costs " + resultstext + " using Pay upon Pickup after discount of " + conversiontext + " loyalty points."
                    End If

                ElseIf radWraps.Checked = True Then
                    If radPre.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = wraps - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Pinwheel Wraps Plater costs " + resultstext + " using Pre-Pay after discount of " + conversiontext + " loyalty points."
                    ElseIf radPickup.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = wraps - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Pinwheel Wraps Plater costs " + resultstext + " using Pay upon Pickup after discount of " + conversiontext + " loyalty points."
                    End If
                ElseIf radVeggie.Checked = True Then
                    If radPre.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = veggie - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Veggie Plater costs " + resultstext + " using Pre-Pay after discount of " + conversiontext + " loyalty points."
                    ElseIf radPickup.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = veggie - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Veggie Plater costs " + resultstext + " using Pay upon Pickup after discount of " + conversiontext + " loyalty points."
                    End If
                ElseIf radSausage.Checked = True Then
                    If radPre.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = sausage - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Sausage and Cheese Plater costs " + resultstext + " using Pre-Pay after discount of " + conversiontext + " loyalty points."
                    ElseIf radPickup.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = sausage - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Sausage and Cheese Plater costs " + resultstext + " using Pay upon Pickup after discount of " + conversiontext + " loyalty points."
                    End If
                ElseIf radFruits.Checked = True And (radPre.Checked = True Or radPickup.Checked) = True Then
                    If radPre.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = fruits - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Fruits Plater costs " + resultstext + " using Pre-Pay after discount of " + conversiontext + " loyalty points."
                    ElseIf radPickup.Checked = True Then
                        calculate = conversion / loyalty
                        percentage = calculate * discount
                        results = fruits - percentage
                        If results < 0 Then
                            MsgBox("You can't use that many loyalty points")
                            txtPoints.Text = ""
                        End If
                        resultstext = Convert.ToString(results)
                        conversiontext = Convert.ToString(conversion)
                        lblResults.Text = "Your order Fruits Plater costs " + resultstext + " using Pay upon Pickup after discount of " + conversiontext + " loyalty points."
                    End If
                End If

                Else
                    MsgBox("The value you have entered is not positive")
                txtPoints.Text = ""
            End If
        Else
            MsgBox("The value you have entered is not numeric")
            txtPoints.Text = ""

        End If
    End Sub
End Class
